public class Principal {

    public static void main(String[] args) {

        Pessoa p1 = new Pessoa("Leonardo",1080354069,2);
        Endereco e1 = new Endereco("Rua professor samuel bruce","Inatel",20);
        Endereco e2 = new Endereco("Rua regis salles de paula","Jardim paraiso",31);
        Pessoa p2 = new Pessoa("Ayeska",1080354069,2);
        Endereco e3 = new Endereco("Rua sebatiao moreira da silva","Inatel",20);
        Endereco e4 = new Endereco("Rua comendador jose garcia","Jardim paraiso",31);
        p1.addEndereco(e1);
        p1.addEndereco(e2);
        p2.addEndereco(e3);
        p1.addEndereco(e4);

        p1.mostraInfo();
        p2.mostraInfo();


    }

}
